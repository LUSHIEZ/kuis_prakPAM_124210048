package com.example.pertemuanlima

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
