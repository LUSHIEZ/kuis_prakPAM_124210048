import 'dart:html';

import 'package:flutter/material.dart';
import 'package:kuis_048_ariq/disease_data.dart';
import 'package:kuis_048_ariq/tourism_place.dart';
import 'package:url_launcher/url_launcher.dart';

class halamandetail extends StatefulWidget {
  const halamandetail({super.key, required this.tanaman});
  final Diseases tanaman;

  @override
  State<halamandetail> createState() => _halamandetailState();
}

class _halamandetailState extends State<halamandetail> {
  bool isFavorite = false;

  void toggleFavorite() {
  setState(() {
  isFavorite = !isFavorite;
  });


  var snackBar = SnackBar(
  content: Text(
  isFavorite ? 'Ditambahkan ke Favorit' : 'Dihapus dari Favorit',
  ),

    backgroundColor: (isFavorite)? Colors.green: Colors.red,
    duration: Duration(seconds: 1),
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Halaman Detail"),
        backgroundColor: Colors.greenAccent,
          actions: <Widget>[

            IconButton(

                icon:Icon(isFavorite?Icons.favorite:Icons.favorite_border),
                 onPressed: toggleFavorite,

            ),
        ],


      ),
      body: ListView(
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height / 3,
            width: MediaQuery.of(context).size.width,
            child: Image.network(widget.tanaman. imgUrls),
          ),
          Padding(
            padding: const EdgeInsets.all(40.0),
            child: Center(child: Column(
              children: [
                Text("Disease Name",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),
                ),
                Text(widget.tanaman.name,),
                SizedBox(height: 20,),

                Text("Plant Name",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),
                ),
                Text(widget.tanaman.plantName,),
                SizedBox(height: 20,),

                Text("Ciri-ciri",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),
                ),

                Text(widget.tanaman.nutshell[0]),
                Text(widget.tanaman.nutshell[1]),
                SizedBox(height: 20,),

                Text("Disease ID",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),
                ),
                Text(widget.tanaman.id),
                SizedBox(height: 20,),

                Text("Symptom",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),
                ),
                Text(widget.tanaman.symptom),
                SizedBox(height: 10,),

              ],
            ),
            ),
          ),
          SizedBox(height: 40,),
          TextButton(
            onPressed:() {
            },
            child: Text('link gambar dibawah ini',
              style: TextStyle(
                color: Colors.red,
                  fontWeight: FontWeight.bold

              ),
            ),
          ),

          IconButton(onPressed: (){
            _launcher(widget.tanaman.imgUrls);
          }, icon: Icon(Icons.link)),
          SizedBox(height: 20,),

          TextButton(
            onPressed:() {
            },
            child: Text('link SPADA dibawah ini',
            style: TextStyle(
              color: Colors.red,
                fontWeight: FontWeight.bold
              )
            )
          ),

          IconButton(onPressed: (){
            _launcher("https://spada.upnyk.ac.id");
          }, icon: Icon(Icons.link)),

          SizedBox(height: 20,),


        ],
      ),
    );
  }

  Future<void> _launcher(String url) async{
    final Uri _url = Uri.parse(url);
    if(!await launchUrl(_url)){
      throw Exception("gagal membuka url : $_url");
    }
  }
}
