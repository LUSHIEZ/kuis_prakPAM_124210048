import 'package:flutter/material.dart';
import 'package:kuis_048_ariq/disease_data.dart';
import 'package:kuis_048_ariq/halamandetail.dart';
import 'package:kuis_048_ariq/tourism_place.dart';

class halamanutama extends StatelessWidget {
  const halamanutama({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.greenAccent,
        title: Text('Halaman Utama'),
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
        itemCount: listDisease.length,
        itemBuilder: (context, index)
        {
          final Diseases penyakit = listDisease[index];
          return InkWell(
            onDoubleTap: () {

              Navigator.push(context, MaterialPageRoute(builder: (context) => halamandetail(tanaman : penyakit,),
              )
              );
            },
            child: Card(
              child: SizedBox(
                height: 200,
                width: double.infinity,
                child: Column(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width /7 ,
                        child: Image.network(
                            penyakit.imgUrls,
                            fit: BoxFit.fill,
                        ),
                    ),
                    Text(penyakit.name),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
